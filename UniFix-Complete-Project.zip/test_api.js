const path = require('path');

async function runTests() {
  const BASE = 'http://localhost:3000';

  console.log('🧪 Starting UniFix End-to-End API Verification Tests...\n');

  // Test 1: Health / Static HTML
  const htmlRes = await fetch(BASE);
  const htmlText = await htmlRes.text();
  console.assert(htmlText.includes('UniFix'), 'Test 1 Failed: HTML does not contain UniFix');
  console.log('✓ Test 1 Passed: Static HTML served correctly');

  // Test 2: Stats
  const statsRes = await fetch(`${BASE}/api/stats`);
  const stats = await statsRes.json();
  console.assert(stats.totalPcs === 170, `Test 2 Failed: totalPcs expected 170, got ${stats.totalPcs}`);
  console.assert(stats.labs.length === 5, `Test 2 Failed: expected 5 labs, got ${stats.labs.length}`);
  console.log(`✓ Test 2 Passed: Stats API verified (${stats.totalPcs} PCs across ${stats.labs.length} labs)`);

  // Test 3: Auth Login
  const loginRes = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'student@college.edu', password: 'password123' })
  });
  const loginData = await loginRes.json();
  console.assert(loginData.success === true, 'Test 3 Failed: Login unsuccessful');
  console.assert(loginData.user.role === 'STUDENT', 'Test 3 Failed: Role mismatch');
  console.log(`✓ Test 3 Passed: User login verified (${loginData.user.name} - ${loginData.user.role})`);

  // Test 4: File a New Complaint
  const labId = 'MB-407/408';
  const pcNum = 'PC-15';
  const pcId = `${labId}-${pcNum}`;

  const reportRes = await fetch(`${BASE}/api/complaints`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      labId,
      pcNum,
      problemType: 'Keyboard Problem',
      description: 'Keys sticky and spacebar not working during coding lab.',
      studentName: 'Sachitanand Borkar'
    })
  });
  const reportData = await reportRes.json();
  console.assert(reportData.success === true, 'Test 4 Failed: Complaint creation failed');
  const ticketId = reportData.complaint.id;
  console.log(`✓ Test 4 Passed: Complaint filed with ID: ${ticketId}`);

  // Test 5: Verify PC status is NOT_WORKING
  const pcRes1 = await fetch(`${BASE}/api/pcs/${encodeURIComponent(pcId)}`);
  const pcData1 = await pcRes1.json();
  console.assert(pcData1.status === 'NOT_WORKING', `Test 5 Failed: PC status should be NOT_WORKING, got ${pcData1.status}`);
  console.log(`✓ Test 5 Passed: ${pcId} transitioned to NOT_WORKING`);

  // Test 6: Admin Assigns Technician
  const assignRes = await fetch(`${BASE}/api/complaints/${encodeURIComponent(ticketId)}/assign`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ technician: 'Sachin Sakhare' })
  });
  const assignData = await assignRes.json();
  console.assert(assignData.complaint.status === 'In Progress', 'Test 6 Failed: Status should be In Progress');
  console.assert(assignData.complaint.assigned_to === 'Sachin Sakhare', 'Test 6 Failed: Tech not assigned');
  console.log(`✓ Test 6 Passed: Ticket assigned to Sachin Sakhare`);

  // Test 7: Verify PC status is UNDER_MAINTENANCE
  const pcRes2 = await fetch(`${BASE}/api/pcs/${encodeURIComponent(pcId)}`);
  const pcData2 = await pcRes2.json();
  console.assert(pcData2.status === 'UNDER_MAINTENANCE', `Test 7 Failed: PC should be UNDER_MAINTENANCE, got ${pcData2.status}`);
  console.log(`✓ Test 7 Passed: ${pcId} transitioned to UNDER_MAINTENANCE`);

  // Test 8: Technician Resolves Complaint
  const resolveRes = await fetch(`${BASE}/api/complaints/${encodeURIComponent(ticketId)}/resolve`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      resolution: 'Replaced faulty keyboard with a new mechanical unit and tested all keys.',
      resolvedBy: 'Sachin Sakhare'
    })
  });
  const resolveData = await resolveRes.json();
  console.assert(resolveData.complaint.status === 'Resolved', 'Test 8 Failed: Complaint should be Resolved');
  console.log(`✓ Test 8 Passed: Ticket marked Resolved`);

  // Test 9: Verify PC status restored to WORKING
  const pcRes3 = await fetch(`${BASE}/api/pcs/${encodeURIComponent(pcId)}`);
  const pcData3 = await pcRes3.json();
  console.assert(pcData3.status === 'WORKING', `Test 9 Failed: PC should be restored to WORKING, got ${pcData3.status}`);
  console.log(`✓ Test 9 Passed: ${pcId} restored to WORKING (operational green)`);

  // Test 10: Notifications
  const notifRes = await fetch(`${BASE}/api/notifications`);
  const notifs = await notifRes.json();
  console.assert(Array.isArray(notifs) && notifs.length > 0, 'Test 10 Failed: Notifications missing');
  console.log(`✓ Test 10 Passed: ${notifs.length} notifications logged in database`);

  console.log('\n🎉 ALL 10 END-TO-END VERIFICATION TESTS PASSED SUCCESSFULLY!');
  process.exit(0);
}

runTests().catch(err => {
  console.error('❌ Test failed with error:', err);
  process.exit(1);
});
