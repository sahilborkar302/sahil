# UniFix – College Computer Lab Support & Diagnostics System

UniFix is a full-stack, responsive computer lab support and diagnostics web application. It enables students, faculty, IT administrators, and technicians to monitor computer lab seating health, report faulty computers, assign technicians, and track hardware/software repairs in real-time.

---

## 🚀 Features

- **Real-Time Node.js & SQLite Backend**:
  - Embedded ACID storage powered by Node 24 native `node:sqlite` (`unifix.db`).
  - Zero heavy external database installations or native compiler dependencies.
  - Full REST API for authentication, labs, PCs, tickets, and notifications.
  - Server-Sent Events (SSE) for instant cross-device live synchronization.
- **Fully Responsive Architecture**:
  - **Mobile (< 768px)**: Streamlined mobile app layout with bottom navigation bar, floating action button, and touch bottom sheets.
  - **Tablet (768px – 1024px)**: Centered floating modals, 4-column metric bar, 2-column lab grid, and adaptive ticket cards.
  - **Desktop (≥ 1024px)**: Top desktop navigation bar with active indicators, quick report button, split dashboard view with live activity feed, and expanded interactive classroom seating layout.
- **Role-Based Workflow**:
  - **Student**: View lab seating layouts, check working PCs, and file problem reports with 1 tap.
  - **IT Admin**: Triage incoming complaints, assign technicians, monitor lab operational rates.
  - **Support Technician**: Review work queue, input repair notes, and resolve tickets (restoring PCs to operational green).

---

## 📦 Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Start the Server
```bash
npm start
```
The server will start at: **`http://localhost:3000`**

### 3. Open in Browser
Navigate to **`http://localhost:3000`** in your browser.

---

## 🔐 Default Demo Accounts

| Role | Email | Password | Description |
| :--- | :--- | :--- | :--- |
| **Student** | `student@college.edu` | `password123` | Report problems & view seating |
| **Admin** | `admin@college.edu` | `password123` | Assign technicians & triage |
| **Technician** | `tech@college.edu` | `password123` | Resolve tickets & log repair notes |

*(You can also click on the account chip in the top right to instantly switch roles or sign up a new user.)*

---

## 📡 REST API Reference

| Endpoint | Method | Description |
| :--- | :--- | :--- |
| `/api/stats` | `GET` | Aggregated statistics across all labs |
| `/api/labs` | `GET` | All 5 computer labs with operational health counts |
| `/api/labs/:id` | `GET` | Detailed lab layout with all individual PC states |
| `/api/pcs/:pcId` | `GET` | PC maintenance logs and ticket history |
| `/api/complaints` | `GET` | List complaints (filter by `status`, `labId`, `assignedTo`) |
| `/api/complaints` | `POST` | File a new complaint (auto-turns PC red `NOT_WORKING`) |
| `/api/complaints/:id/assign` | `PATCH` | Assign technician (moves PC to `UNDER_MAINTENANCE`) |
| `/api/complaints/:id/resolve` | `PATCH` | Resolve complaint (restores PC to `WORKING`) |
| `/api/auth/login` | `POST` | Login with email and password |
| `/api/auth/register` | `POST` | Register a new user |
| `/api/notifications` | `GET` | Retrieve latest system notifications |
| `/api/events` | `GET` | Server-Sent Events (SSE) real-time stream |
