const express = require('express');
const cors = require('cors');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'unifix.db');

// Setup Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

// Initialize Database
const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA journal_mode = WAL;');

// Database Schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'STUDENT',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS labs (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    pc_count INTEGER NOT NULL,
    layout_type TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS pcs (
    id TEXT PRIMARY KEY,
    lab_id TEXT NOT NULL,
    pc_num TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'WORKING',
    slot_num INTEGER NOT NULL,
    FOREIGN KEY (lab_id) REFERENCES labs(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS pc_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pc_id TEXT NOT NULL,
    log_date TEXT NOT NULL,
    text TEXT NOT NULL,
    color TEXT DEFAULT '',
    FOREIGN KEY (pc_id) REFERENCES pcs(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS complaints (
    id TEXT PRIMARY KEY,
    lab_id TEXT NOT NULL,
    pc_id TEXT NOT NULL,
    pc_num TEXT NOT NULL,
    student_name TEXT NOT NULL,
    problem_type TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending',
    assigned_to TEXT DEFAULT NULL,
    resolution TEXT DEFAULT NULL,
    date TEXT NOT NULL,
    date_time TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (lab_id) REFERENCES labs(id) ON DELETE CASCADE,
    FOREIGN KEY (pc_id) REFERENCES pcs(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    color TEXT NOT NULL DEFAULT '#4f46e5',
    time TEXT NOT NULL,
    read INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
  );
`);

// Helpers
const hashPassword = (pw) => crypto.createHash('sha256').update(pw).digest('hex');
const nowStr = () => new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const todayStr = () => new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

// In-Memory Sessions
const sessions = new Map();

// SSE Broadcast System
const sseClients = new Set();
function broadcast(eventType, payload) {
  const message = `event: ${eventType}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(message);
    } catch (e) {
      sseClients.delete(client);
    }
  }
}

// Keep-Alive for SSE
setInterval(() => {
  for (const client of sseClients) {
    try {
      client.write(': ping\n\n');
    } catch (e) {
      sseClients.delete(client);
    }
  }
}, 25000);

// Seed Data Initialization
function seedDatabase() {
  const checkLabs = db.prepare('SELECT COUNT(*) as count FROM labs').get();
  if (checkLabs.count > 0) return;

  console.log('🌱 Seeding UniFix database with initial labs, PCs, and users...');

  // 1. Seed Default Users
  const insertUser = db.prepare('INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)');
  insertUser.run('Sachitanand Borkar', 'student@college.edu', hashPassword('password123'), 'STUDENT', nowStr());
  insertUser.run('Mrs. Suchitra Sonawane', 'admin@college.edu', hashPassword('password123'), 'ADMIN', nowStr());
  insertUser.run('Sachin Sakhare', 'tech@college.edu', hashPassword('password123'), 'TECHNICIAN', nowStr());
  insertUser.run('Rahul Sharma', 'rahul@college.edu', hashPassword('password123'), 'TECHNICIAN', nowStr());
  insertUser.run('Priya Patel', 'priya@college.edu', hashPassword('password123'), 'TECHNICIAN', nowStr());

  // 2. Seed Labs
  const LAB_CONFIGS = [
    { id: 'MB-407/408', name: 'Computer Lab MB-407/408', pcCount: 80, type: '80_GRID' },
    { id: 'MB-407 B', name: 'Computer Lab MB-407 B', pcCount: 21, type: '2_COL_SWAPPED' },
    { id: 'MB-408 B', name: 'Computer Lab MB-408 B', pcCount: 21, type: '2_COL_ORIGINAL' },
    { id: 'MB-409', name: 'Computer Lab MB-409', pcCount: 24, type: '24_GRID' },
    { id: 'MB-414', name: 'Computer Lab MB-414', pcCount: 24, type: '24_GRID' }
  ];

  const insertLab = db.prepare('INSERT INTO labs (id, name, pc_count, layout_type) VALUES (?, ?, ?, ?)');
  const insertPc = db.prepare('INSERT INTO pcs (id, lab_id, pc_num, status, slot_num) VALUES (?, ?, ?, ?, ?)');
  const insertLog = db.prepare('INSERT INTO pc_logs (pc_id, log_date, text, color) VALUES (?, ?, ?, ?)');
  const insertComplaint = db.prepare(`
    INSERT INTO complaints (id, lab_id, pc_id, pc_num, student_name, problem_type, description, status, assigned_to, resolution, date, date_time, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  let complaintCounter = 101;

  for (const lab of LAB_CONFIGS) {
    insertLab.run(lab.id, lab.name, lab.pcCount, lab.type);

    for (let p = 1; p <= lab.pcCount; p++) {
      const pcNum = `PC-${String(p).padStart(2, '0')}`;
      const pcId = `${lab.id}-${pcNum}`;
      let status = 'WORKING';
      const rand = Math.random();

      if (rand > 0.94) {
        status = 'NOT_AVAILABLE';
      } else if (rand > 0.86) {
        status = 'UNDER_MAINTENANCE';
      } else if (rand > 0.78) {
        status = 'NOT_WORKING';
      }

      insertPc.run(pcId, lab.id, pcNum, status, p);
      insertLog.run(pcId, '10 Aug 2026, 09:00 am', 'System installed and verified.', 'green');

      if (status === 'NOT_AVAILABLE') {
        insertLog.run(pcId, '02 Sep 2026, 11:00 am', 'Marked not available for hardware upgrade.', '');
      } else if (status === 'UNDER_MAINTENANCE') {
        insertLog.run(pcId, '20 Sep 2026, 10:30 am', 'Sent for routine scheduled maintenance.', 'yellow');
      } else if (status === 'NOT_WORKING') {
        const cId = `REPORT-2026-${String(complaintCounter++).padStart(6, '0')}`;
        insertLog.run(pcId, '23 Sep 2026, 02:15 pm', `Complaint ${cId} reported: Screen flickering continuously.`, 'red');
        insertComplaint.run(
          cId, lab.id, pcId, pcNum,
          'Ananya Roy', 'Monitor Problem', 'Screen flickering continuously and display goes black.',
          'Pending', null, null,
          '23 Sep 2026', '23 Sep 2026, 02:15 pm', new Date().toISOString()
        );
      }
    }
  }

  // 3. Seed Notifications
  const insertNotif = db.prepare('INSERT INTO notifications (text, color, time, created_at) VALUES (?, ?, ?, ?)');
  insertNotif.run('PC MB-407/408-PC-05 marked UNDER MAINTENANCE.', '#f59e0b', nowStr(), new Date().toISOString());
  insertNotif.run('System diagnostics completed across all labs.', '#4f46e5', nowStr(), new Date().toISOString());

  console.log('✅ UniFix database seeded successfully.');
}
seedDatabase();

// ---------------------------------------------------------------------------
// AUTH ROUTES
// ---------------------------------------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  try {
    const validRole = ['STUDENT', 'ADMIN', 'TECHNICIAN'].includes(role) ? role : 'STUDENT';
    const pwHash = hashPassword(password);
    const stmt = db.prepare('INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)');
    const result = stmt.run(name.trim(), email.toLowerCase().trim(), pwHash, validRole, nowStr());

    const token = crypto.randomBytes(24).toString('hex');
    const user = { id: Number(result.lastInsertRowid), name, email: email.toLowerCase().trim(), role: validRole };
    sessions.set(token, user);

    res.json({ success: true, token, user });
  } catch (err) {
    if (err.message && err.message.includes('UNIQUE')) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }
    res.status(500).json({ error: 'Failed to create account.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const pwHash = hashPassword(password);
  const user = db.prepare('SELECT id, name, email, role FROM users WHERE LOWER(email) = ? AND password_hash = ?')
    .get(email.toLowerCase().trim(), pwHash);

  if (!user) {
    // Check if user exists to provide helpful demo experience
    const existing = db.prepare('SELECT id, name, email, role FROM users WHERE LOWER(email) = ?').get(email.toLowerCase().trim());
    if (existing) {
      return res.status(401).json({ error: 'Incorrect password.' });
    }
    // Auto-create for quick demo if email doesn't exist
    const defaultName = email.split('@')[0] || 'User';
    const newUser = db.prepare('INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?)')
      .run(defaultName, email.toLowerCase().trim(), pwHash, 'STUDENT', nowStr());
    const token = crypto.randomBytes(24).toString('hex');
    const created = { id: Number(newUser.lastInsertRowid), name: defaultName, email: email.toLowerCase().trim(), role: 'STUDENT' };
    sessions.set(token, created);
    return res.json({ success: true, token, user: created });
  }

  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, user);
  res.json({ success: true, token, user });
});

app.get('/api/auth/me', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: 'No token provided' });
  const token = authHeader.replace(/^Bearer\s+/i, '');
  const user = sessions.get(token);
  if (!user) return res.status(401).json({ error: 'Invalid or expired session' });
  res.json({ user });
});

// ---------------------------------------------------------------------------
// STATS & LABS ROUTES
// ---------------------------------------------------------------------------
function computeLabStats() {
  const labs = db.prepare('SELECT * FROM labs').all();
  const pcRows = db.prepare('SELECT lab_id, status, COUNT(*) as count FROM pcs GROUP BY lab_id, status').all();

  const statsMap = {};
  labs.forEach(lab => {
    statsMap[lab.id] = {
      id: lab.id,
      name: lab.name,
      pcCount: lab.pc_count,
      type: lab.layout_type,
      working: 0,
      notWorking: 0,
      maintenance: 0,
      notAvailable: 0
    };
  });

  pcRows.forEach(row => {
    const lab = statsMap[row.lab_id];
    if (lab) {
      if (row.status === 'WORKING') lab.working = row.count;
      else if (row.status === 'NOT_WORKING') lab.notWorking = row.count;
      else if (row.status === 'UNDER_MAINTENANCE') lab.maintenance = row.count;
      else if (row.status === 'NOT_AVAILABLE') lab.notAvailable = row.count;
    }
  });

  return Object.values(statsMap);
}

app.get('/api/stats', (req, res) => {
  const labs = computeLabStats();
  let totalWorking = 0, totalNotWorking = 0, totalMaint = 0, totalNotAvail = 0, totalPcs = 0;

  labs.forEach(l => {
    totalWorking += l.working;
    totalNotWorking += l.notWorking;
    totalMaint += l.maintenance;
    totalNotAvail += l.notAvailable;
    totalPcs += l.pcCount;
  });

  const activeTickets = db.prepare("SELECT COUNT(*) as count FROM complaints WHERE status != 'Resolved'").get().count;
  const availRate = totalPcs > 0 ? ((totalWorking / totalPcs) * 100).toFixed(1) : 0;

  res.json({
    working: totalWorking,
    notWorking: totalNotWorking,
    maintenance: totalMaint,
    notAvailable: totalNotAvail,
    totalPcs,
    availabilityRate: `${availRate}%`,
    activeTickets,
    labs
  });
});

app.get('/api/labs', (req, res) => {
  res.json(computeLabStats());
});

app.get('/api/labs/:id', (req, res) => {
  const labId = decodeURIComponent(req.params.id);
  const lab = db.prepare('SELECT * FROM labs WHERE id = ?').get(labId);
  if (!lab) return res.status(404).json({ error: 'Lab not found' });

  const pcs = db.prepare('SELECT id, lab_id, pc_num, status, slot_num FROM pcs WHERE lab_id = ? ORDER BY slot_num ASC').all(labId);
  res.json({
    id: lab.id,
    name: lab.name,
    pcCount: lab.pc_count,
    type: lab.layout_type,
    pcs
  });
});

// ---------------------------------------------------------------------------
// PC ROUTES
// ---------------------------------------------------------------------------
app.get('/api/pcs/:pcId', (req, res) => {
  const pcId = decodeURIComponent(req.params.pcId);
  const pc = db.prepare('SELECT * FROM pcs WHERE id = ?').get(pcId);
  if (!pc) return res.status(404).json({ error: 'PC not found' });

  const logs = db.prepare('SELECT id, log_date as date, text, color FROM pc_logs WHERE pc_id = ? ORDER BY id DESC').all(pcId);
  const complaints = db.prepare('SELECT * FROM complaints WHERE pc_id = ? ORDER BY created_at DESC').all(pcId);

  res.json({
    ...pc,
    logs,
    complaints
  });
});

app.put('/api/pcs/:pcId/status', (req, res) => {
  const pcId = decodeURIComponent(req.params.pcId);
  const { status, note } = req.body;
  const valid = ['WORKING', 'NOT_WORKING', 'UNDER_MAINTENANCE', 'NOT_AVAILABLE'];
  if (!valid.includes(status)) return res.status(400).json({ error: 'Invalid status' });

  const pc = db.prepare('SELECT * FROM pcs WHERE id = ?').get(pcId);
  if (!pc) return res.status(404).json({ error: 'PC not found' });

  db.prepare('UPDATE pcs SET status = ? WHERE id = ?').run(status, pcId);
  const logNote = note || `Status updated manually to ${status}`;
  const color = status === 'WORKING' ? 'green' : status === 'NOT_WORKING' ? 'red' : status === 'UNDER_MAINTENANCE' ? 'yellow' : '';
  db.prepare('INSERT INTO pc_logs (pc_id, log_date, text, color) VALUES (?, ?, ?, ?)').run(pcId, nowStr(), logNote, color);

  broadcast('pc_updated', { pcId, status, labId: pc.lab_id });
  res.json({ success: true, pcId, status });
});

// ---------------------------------------------------------------------------
// COMPLAINTS & TICKETS ROUTES
// ---------------------------------------------------------------------------
let complaintSeq = null;
function getNextComplaintId() {
  if (complaintSeq === null) {
    const row = db.prepare("SELECT id FROM complaints WHERE id LIKE 'REPORT-2026-%' ORDER BY id DESC LIMIT 1").get();
    if (row && row.id) {
      const match = row.id.match(/\d+$/);
      complaintSeq = match ? parseInt(match[0], 10) + 1 : 101;
    } else {
      complaintSeq = 101;
    }
  } else {
    complaintSeq++;
  }
  return `REPORT-2026-${String(complaintSeq).padStart(6, '0')}`;
}

app.get('/api/complaints', (req, res) => {
  const { status, labId, assignedTo } = req.query;
  let sql = 'SELECT * FROM complaints WHERE 1=1';
  const params = [];

  if (status) {
    sql += ' AND status = ?';
    params.push(status);
  }
  if (labId) {
    sql += ' AND lab_id = ?';
    params.push(labId);
  }
  if (assignedTo) {
    sql += ' AND assigned_to = ?';
    params.push(assignedTo);
  }

  sql += ' ORDER BY created_at DESC';
  const complaints = db.prepare(sql).all(...params);
  res.json(complaints);
});

app.post('/api/complaints', (req, res) => {
  const { labId, pcNum, problemType, description, studentName } = req.body;
  if (!labId || !pcNum || !problemType || !description) {
    return res.status(400).json({ error: 'Missing required report fields.' });
  }

  const pcId = `${labId}-${pcNum}`;
  const pc = db.prepare('SELECT * FROM pcs WHERE id = ?').get(pcId);
  if (!pc) return res.status(404).json({ error: `PC ${pcNum} in lab ${labId} does not exist.` });

  const id = getNextComplaintId();
  const author = studentName && studentName.trim() ? studentName.trim() : 'Student';
  const dateStr = todayStr();
  const dateTimeStr = nowStr();
  const createdAt = new Date().toISOString();

  // 1. Insert Complaint
  db.prepare(`
    INSERT INTO complaints (id, lab_id, pc_id, pc_num, student_name, problem_type, description, status, assigned_to, resolution, date, date_time, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', NULL, NULL, ?, ?, ?)
  `).run(id, labId, pcId, pcNum, author, problemType, description.trim(), dateStr, dateTimeStr, createdAt);

  // 2. Update PC to NOT_WORKING
  db.prepare("UPDATE pcs SET status = 'NOT_WORKING' WHERE id = ?").run(pcId);

  // 3. Add to PC Logs
  db.prepare('INSERT INTO pc_logs (pc_id, log_date, text, color) VALUES (?, ?, ?, ?)').run(
    pcId, dateTimeStr, `Complaint ${id} reported by ${author}: ${problemType} — “${description.trim()}”`, 'red'
  );

  // 4. Add Notification
  const notifText = `New report ${id}: ${labId} / ${pcNum} — ${problemType}`;
  db.prepare('INSERT INTO notifications (text, color, time, created_at) VALUES (?, ?, ?, ?)').run(
    notifText, '#f43f5e', dateTimeStr, createdAt
  );

  const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(id);

  // 5. Broadcast SSE event
  broadcast('new_complaint', {
    complaint,
    pcId,
    labId,
    status: 'NOT_WORKING',
    notification: { text: notifText, color: '#f43f5e', time: dateTimeStr }
  });

  res.status(201).json({ success: true, complaint });
});

app.patch('/api/complaints/:id/assign', (req, res) => {
  const { id } = req.params;
  const { technician } = req.body;
  if (!technician) return res.status(400).json({ error: 'Technician name is required.' });

  const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found.' });

  // Update complaint
  db.prepare("UPDATE complaints SET assigned_to = ?, status = 'In Progress' WHERE id = ?").run(technician, id);

  // Update PC to UNDER_MAINTENANCE
  db.prepare("UPDATE pcs SET status = 'UNDER_MAINTENANCE' WHERE id = ?").run(complaint.pc_id);

  // Add Log
  db.prepare('INSERT INTO pc_logs (pc_id, log_date, text, color) VALUES (?, ?, ?, ?)').run(
    complaint.pc_id, nowStr(), `Ticket ${id} assigned to ${technician}. PC moved to maintenance.`, 'yellow'
  );

  // Notification
  const notifText = `Ticket ${id} assigned to ${technician} — ${complaint.pc_num} is under maintenance.`;
  db.prepare('INSERT INTO notifications (text, color, time, created_at) VALUES (?, ?, ?, ?)').run(
    notifText, '#f59e0b', nowStr(), new Date().toISOString()
  );

  const updatedComplaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(id);

  broadcast('ticket_assigned', {
    complaint: updatedComplaint,
    pcId: complaint.pc_id,
    labId: complaint.lab_id,
    status: 'UNDER_MAINTENANCE',
    notification: { text: notifText, color: '#f59e0b', time: nowStr() }
  });

  res.json({ success: true, complaint: updatedComplaint });
});

app.patch('/api/complaints/:id/resolve', (req, res) => {
  const { id } = req.params;
  const { resolution, resolvedBy } = req.body;

  const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(id);
  if (!complaint) return res.status(404).json({ error: 'Complaint not found.' });

  const resText = resolution && resolution.trim() ? resolution.trim() : 'Hardware fixed and re-tested by technician.';
  const tech = resolvedBy || complaint.assigned_to || 'Support Tech';

  // Mark complaint resolved
  db.prepare("UPDATE complaints SET status = 'Resolved', resolution = ?, assigned_to = COALESCE(assigned_to, ?) WHERE id = ?")
    .run(resText, tech, id);

  // Check if any remaining pending complaints exist for this PC
  const remaining = db.prepare("SELECT COUNT(*) as count FROM complaints WHERE pc_id = ? AND status != 'Resolved'").get(complaint.pc_id);
  let newPcStatus = 'WORKING';
  if (remaining.count > 0) {
    newPcStatus = 'NOT_WORKING';
  }

  db.prepare('UPDATE pcs SET status = ? WHERE id = ?').run(newPcStatus, complaint.pc_id);

  // Add PC Log
  db.prepare('INSERT INTO pc_logs (pc_id, log_date, text, color) VALUES (?, ?, ?, ?)').run(
    complaint.pc_id, nowStr(), `Ticket ${id} resolved by ${tech}: ${resText}`, 'green'
  );

  // Notification
  const notifText = `Ticket ${id} resolved — ${complaint.pc_num} in ${complaint.lab_id} is restored to WORKING.`;
  db.prepare('INSERT INTO notifications (text, color, time, created_at) VALUES (?, ?, ?, ?)').run(
    notifText, '#10b981', nowStr(), new Date().toISOString()
  );

  const updatedComplaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(id);

  broadcast('ticket_resolved', {
    complaint: updatedComplaint,
    pcId: complaint.pc_id,
    labId: complaint.lab_id,
    status: newPcStatus,
    notification: { text: notifText, color: '#10b981', time: nowStr() }
  });

  res.json({ success: true, complaint: updatedComplaint, pcStatus: newPcStatus });
});

// ---------------------------------------------------------------------------
// NOTIFICATIONS ROUTES
// ---------------------------------------------------------------------------
app.get('/api/notifications', (req, res) => {
  const notifs = db.prepare('SELECT * FROM notifications ORDER BY id DESC LIMIT 50').all();
  res.json(notifs);
});

app.post('/api/notifications/clear', (req, res) => {
  db.prepare('DELETE FROM notifications').run();
  broadcast('notifications_cleared', {});
  res.json({ success: true });
});

// ---------------------------------------------------------------------------
// REAL-TIME SSE ENDPOINT
// ---------------------------------------------------------------------------
app.get('/api/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  sseClients.add(res);

  res.write(`event: connected\ndata: ${JSON.stringify({ time: new Date() })}\n\n`);

  req.on('close', () => {
    sseClients.delete(res);
  });
});

// Serve frontend main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'CEP.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`🚀 UniFix Server running at: http://localhost:${PORT}`);
  console.log(`📱 Responsive Desktop, Tablet & Mobile Web App Ready`);
  console.log(`=======================================================`);
});
